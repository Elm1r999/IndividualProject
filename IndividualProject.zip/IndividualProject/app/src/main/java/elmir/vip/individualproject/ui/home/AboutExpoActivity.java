package elmir.vip.individualproject.ui.home;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import elmir.vip.individualproject.R;

public class AboutExpoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_expo);
    }
}
