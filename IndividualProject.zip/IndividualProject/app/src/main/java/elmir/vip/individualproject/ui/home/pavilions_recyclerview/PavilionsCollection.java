package elmir.vip.individualproject.ui.home.pavilions_recyclerview;

import java.util.ArrayList;

public class PavilionsCollection {
    public static ArrayList<Pavilion> getPavilions() {
        ArrayList<Pavilion> arrayList = new ArrayList<>();
        Pavilion pavilion = new Pavilion();
        //Add Data
        pavilion.setName("Australia");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/australia/expo2020-pavilion-australia-1-1600-x-900.jpg");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Austria");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/austria/expo2020-pavilion-austria1-3200-x-2000.jpg?h=1800&w=3200&hash=78B3F2BD2A7B057A16F835C3185209DE");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Azerbaijan");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/azerbaijan/expo2020-azerbaijan-1-3200-x-1800.jpg?h=1800&w=3200&hash=A2E19A05A78F775545633204E9483D66");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Belarus");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/belarus/expo2020-pavilion-belarus-2-3200-x-1800.jpg?h=1800&w=3200&hash=7778C19864DD4974A30629932C06D58D");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Belgium");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/belgium/expo2020-belgium-1-3200-x-1800.jpg?h=1800&w=3200&hash=E986AC8060058D702BFB62B6DE5ACB2A");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Brazil");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/brazil/expo2020-pavilion-brazil-2-3200-x-2000.jpg?h=1800&w=3200&hash=290FB3F880E7A7827BFFCB31C55C1C3F");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Canada");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/canada/expo2020-pavilion-canada-1-3200-x-1800.jpg?h=1800&w=3200&hash=EC92D8FA4C89DDF32E39FA4338D0DF04");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("China");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/china/expo2020-china-1-3200-x-1800.jpg?h=1800&w=3200&hash=BF9A8650B20741B2972FAD08D2E15D0A");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Czech Republic");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/czech-republic/expo2020-pavilion-czechrepublic-1-3200-x-2000.jpg?h=1800&w=3200&hash=FFB2EFB9AFFDEA277EE76634DA0CC8BE");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Finland");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/finland/expo2020-pavilion-finland-1-3200-x-2000.jpg?h=1800&w=3200&hash=617F49D26ED5A81380462C92FC75CD70");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("France");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/france/expo2020-france-3-3200-x-1800.jpg?h=1800&w=3200&hash=A9671C0538753A7BF214D933F2A66F15");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Germany");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/germany/expo2020-pavilion-germany-3-3200-x-2000.jpg?h=1800&w=3200&hash=E73062AF7F7955D11E03C4ABCBE6E6CE");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("India");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/india/expo2020-pavilion-india-1-3200-x-1800.jpg?h=1080&w=1920&hash=FCFFACC518BE418F5441A5947390C150");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Italy");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/italy/expo2020-italy-3-3200-x-1800.jpg?h=1800&w=3200&hash=0DBC7861E3F700BE47214F1C4FC635A7");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Japan");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/japan/expo2020-pavilion-japan-3-3200-x-1800.jpg?h=1080&w=1920&hash=B4A3F3A6477B2832FCA0666F0545D5AE");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Republic of Korea");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/korea/expo2020-pavilion-korea-1-3200-x-1800.jpg?h=1800&w=3200&hash=CFC2B39BC71A351A1F6CDF1195E03DED");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Latvia");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/latvia/expo2020-pavilion-latvia-2-1600-x-900.jpg");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Luxembourg");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/luxembourg/expo2020-pavilion-luxembourg-2-3200-x-1800.jpg?h=1800&w=3200&hash=95C63D07B549F80E165ABA57A90CACF3");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Malaysia");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/malaysia/expo2020-pavilion-malaysia-3-3200-x-1800.jpg?h=1080&w=1920&hash=0755310C5121E4E8F3E03A15847C316B");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Monaco");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/monaco/expo2020-monaco-1-3200-x-1800.jpg?h=1800&w=3200&hash=82CC99C24A31F9E0C73BBDA3AC558A51");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Montenegro");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/montenegro/expo2020-montenegro-1-3200-x-1800.jpg?h=1080&w=1920&hash=E12BA7CE2D4C08109410A4B3604609ED");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Morocco");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/morocco/expo2020-morocco-1-3200-x-1800.jpg?h=1080&w=1920&hash=E13FBCEB7981BB16C45787D85AF6F51C");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Netherlands");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/netherlands/expo2020-pavilion-netherlands-2-3200-x-2000.jpg?h=1800&w=3200&hash=AA12E755CAE8808E0AB9BA3EFE98BC5C");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("New Zealand");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/new-zealand/expo2020-pavilion-newzealand-3-3200-x-1800.jpg?h=1800&w=3200&hash=2B5FEEFC06E93F07F61575A1C04B9DE5");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Norway");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/norway/expo2020-norway-2-3200-x-1800.jpg?h=1800&w=3200&hash=CA6259DDA59F24FA5909A869DC4046BA");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Oman");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/oman/expo2020-pavilion-oman-2-3200-x-2000.jpg?h=1800&w=3200&hash=C2D91A0CD6977DE3DEAA2AEF44221A0C");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Peru");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/peru/expo2020-pavilion-peru-1-3200-x-1800.jpg?h=1800&w=3200&hash=BE59E7EADFAD46351B849DD89EE53D1B");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Philippines");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/philippines/expo2020-philippines-1-3200-x-1800.jpg?h=1800&w=3200&hash=BCA630E274D129AF63353BC17382D828");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Poland");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/poland/expo2020-pavilion-poland-1-3200-x-2000.jpg?h=1800&w=3200&hash=2A8ECB0DCB7E389D90E783F407F73487");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Russia");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/russia/expo2020-pavilion-russia-1-3200-x-1800.jpg?h=1800&w=3200&hash=F658E4A4E551FC2B9781E49C002A24E5");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Saudi Arabia");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/ksa/expo2020-ksa-1-3200-x-1800.jpg?h=1800&w=3200&hash=3D31FDF6C22E9397926BB4C8BBEA1471");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Singapore");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/singapore/expo2020-pavilion-singapore-1-3200-x-1800.jpg?h=1080&w=1920&hash=719E40B958BACEB8CC604EDCDC9B4E2A");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Spain");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/spain/expo2020-pavilion-spain-1-3200-x-1800.jpg?h=1800&w=3200&hash=D197178A827D8693791B7EE179C46FB5");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Sweden");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/sweden/expo2020-pavilion-sweden-3-3200-x-2000.jpg?h=1800&w=3200&hash=FD608A16E9CF469C4D2BB0B6A0D653A3");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Switzerland");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/switzerland/expo2020-pavilion-switzerland-1-3200-x-2000.jpg?h=1800&w=3200&hash=B623AD2913808437C83FF865A160F36D");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Thailand");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/thailand/expo2020-pavilion-thailand-1-3200-x-2000.jpg?h=1800&w=3200&hash=CDFFC92C0F389077702E6736825089B8");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Turkmenistan");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/turkmenistan/expo2020-turkmenistan-2-3200-x-1800.jpg?h=1800&w=3200&hash=18A992C877BF8AF29744A5FBE3014AFA");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("UAE");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/uae/expo2020-pavilion-uae-1-3200-x-2000.jpg?h=1800&w=3200&hash=1DF0F55DDBF7A314470B061E6921AC0B");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("UK");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/uk/expo2020-pavilion-uk-2-3200-x-2000.jpg?h=1800&w=3200&hash=7E50A2E2D9C934F422ED2CB4D6250B38");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("Ukraine");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/ukraine/expo2020-ukraine-3200x1800.jpg?h=1800&w=3200&hash=C2D9473443F588ED4440A39F41B21B7E    ");
        arrayList.add(pavilion);

        pavilion = new Pavilion();
        pavilion.setName("USA");
        pavilion.setUrl("https://www.expo2020dubai.com/-/media/expo2020/pavilions/usa/expo2020-pavilion-usa-1-3200-x-2000.jpg?h=1800&w=3200&hash=C91E28B2C94E0E26C89C315898BF6118");
        arrayList.add(pavilion);

        return arrayList;
    }
}
